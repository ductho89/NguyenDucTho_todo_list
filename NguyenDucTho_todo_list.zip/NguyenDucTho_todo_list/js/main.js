function getEle(id) {
  return document.getElementById(id);
}

var danhSachTask = new TaskList();
getLocalStorage();

// Thêm task mới vào list
function addTask() {
  // Lấy thông tin do người dùng nhập vào
  var _id = Math.random();
  var _taskName = getEle("newTask").value;
  console.log(_taskName);
  var _status = "todo";
  if (_taskName == " ") {
    alert("Task empty!");
  } else {
    //Tạo object Task mới
    var newTask = new Task(_id, _taskName, _status);

    //Thêm vào danh sách task ban đầu
    danhSachTask._themTask(newTask);
    alert("Add Success!");
    createContent(danhSachTask.arr);
    setLocalStorage();
    console.log(danhSachTask);
  }
}

// Tạo li trong ul để hiển thị ra ngoài màn hình chính
function createContent(arr) {
  var contentToDo = "";
  var contentCompleted = "";
  for (var i = 0; i < arr.length; i++) {
    if (arr[i].status === "todo") {
      contentToDo += `
    <li>
        <span>${arr[i].taskName}</span>
        <div class = "buttons">
            <button class="remove" onclick = "deleteTask('${arr[i].id}')">
                <i class="fa fa-trash-alt"></i>
            </button>
            <button class="complete" onclick = "changeStatus('${arr[i].id}')">
                <i class="far fa-check-circle"></i>
            </button>
        </div>
    </li>
        `;
    } else {
      contentCompleted += `
    <li>
        <span>${arr[i].taskName}</span>
        <div class = "buttons">
            <button class="remove" onclick = "deleteTask('${arr[i].id}')">
                <i class="fa fa-trash-alt"></i>
            </button>
            <button class=" complete " onclick = "changeStatus('${arr[i].id}')">
                <i class="fas fa-check-circle"></i>
            </button>
        </div>
    </li>
        `;
    }
  }
  getEle("todo").innerHTML = contentToDo;
  getEle("completed").innerHTML = contentCompleted;
}

// Function để xóa task
function deleteTask(id) {
  console.log(id);
  danhSachTask._xoaTask(id);
  // console.log(danhSachTask.arr);
  alert("Delete Success!");
  createContent(danhSachTask.arr);
  setLocalStorage();
}
// Function để thay đổi trạng thái của task từ todo => completed
//Sau đó thêm vào trong ul với class="completed"
function changeStatus(id) {
  danhSachTask._capNhatTrangThai(id);
  console.log(danhSachTask.arr);
  alert("Change Status Success!");
  createContent(danhSachTask.arr);
  setLocalStorage();
}

/**
 * Lưu danh sách sinh viên xuống localStorage
 * chuyển kiểu JSON => String (JSON.stringify)
 */
function setLocalStorage() {
  //chuyển kiểu JSON => String (JSON.stringify)
  var arrString = JSON.stringify(danhSachTask.arr);

  //Lưu xuống localStorage
  localStorage.setItem("DanhSachTask", arrString);
}

/**
 * Lấy danh sách sinh viên từ localStorage
 * chuyển kiểu String => JSON (JSON.parse)
 */
function getLocalStorage() {
  if (localStorage.getItem("DanhSachTask")) {
    danhSachTask.arr = JSON.parse(localStorage.getItem("DanhSachTask"));
    createContent(danhSachTask.arr);
  }
}
