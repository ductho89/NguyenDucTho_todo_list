function Task(_id, _taskName, _status) {
  this.id = _id;
  this.taskName = _taskName;
  this.status = _status;
}
