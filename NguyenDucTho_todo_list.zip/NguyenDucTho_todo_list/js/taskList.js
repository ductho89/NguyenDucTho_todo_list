function TaskList() {
  // Tạo array rỗng để thêm các task mới vào
  this.arr = [];

  // Method để thêm các task mới vào
  this._themTask = function (Task) {
    this.arr.push(Task);
  };

  // Method xóa task trong taskList
  this._xoaTask = function (id) {
    console.log("oke");
    for (var i = 0; i < this.arr.length; i++) {
      if (this.arr[i].id === parseFloat(id)) {
        // You have to have parseFloat here
        console.log(id);
        // at position i, remove 1 item
        this.arr.splice(i, 1);
        break;
      }
    }
  };
  // Method tìm vị trí của task dựa vào id
  this._timViTri = function (id) {
    var viTri = -1;
    for (var i = 0; i < this.arr.length; i++) {
      if (this.arr[i].id === parseFloat(id)) {
        viTri = parseInt(i);
        break;
      }
      // Trả lại index của task trong mảng
    }
    return viTri;
  };

  //Method để chập nhật lại trạng thái cho task
  this._capNhatTrangThai = function (id) {
    var index = this._timViTri(id);
    console.log(index);
    if (index !== -1) {
      if (this.arr[index].status === "todo") {
        this.arr[index].status = "completed";
      } else {
        this.arr[index].status = "todo";
      }
    }
  };
}

// Them method update trang thai giong nhu danh sach sinh vien
